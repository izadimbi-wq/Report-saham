package com.izadimbi.reportsaham

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class PortfolioDb(context: Context) : SQLiteOpenHelper(context, "portfolio.db", null, 4) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE shareholders (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE)")
        db.execSQL("CREATE TABLE transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, shareholder TEXT NOT NULL, symbol TEXT NOT NULL, type TEXT NOT NULL, qty INTEGER NOT NULL, price INTEGER NOT NULL, date TEXT NOT NULL)")
        db.execSQL("CREATE TABLE daily_reports (id INTEGER PRIMARY KEY AUTOINCREMENT, shareholder TEXT NOT NULL, date TEXT NOT NULL, total_assets INTEGER NOT NULL DEFAULT 0, portfolio_value INTEGER NOT NULL DEFAULT 0, portfolio_pl INTEGER NOT NULL DEFAULT 0, daily_pl INTEGER NOT NULL DEFAULT 0, deposit INTEGER NOT NULL DEFAULT 0, withdrawal INTEGER NOT NULL DEFAULT 0, UNIQUE(shareholder,date))")
        db.execSQL("CREATE INDEX idx_transactions_shareholder_date ON transactions(shareholder,date)")
        db.execSQL("CREATE INDEX idx_daily_reports_shareholder_date ON daily_reports(shareholder,date)")
        seedShareholders(db)
    }

    private fun seedShareholders(db: SQLiteDatabase) {
        val names = listOf("سهامدار ۱", "سهامدار ۲", "سهامدار ۳", "سهامدار ۴", "سهامدار ۵", "سهامدار ۶")
        names.forEach { n -> ContentValues().apply { put("name", n) }.also { db.insert("shareholders", null, it) } }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 3) db.execSQL("CREATE INDEX IF NOT EXISTS idx_transactions_shareholder_date ON transactions(shareholder,date)")
        if (oldVersion < 4) {
            db.execSQL("CREATE TABLE IF NOT EXISTS daily_reports (id INTEGER PRIMARY KEY AUTOINCREMENT, shareholder TEXT NOT NULL, date TEXT NOT NULL, total_assets INTEGER NOT NULL DEFAULT 0, portfolio_value INTEGER NOT NULL DEFAULT 0, portfolio_pl INTEGER NOT NULL DEFAULT 0, daily_pl INTEGER NOT NULL DEFAULT 0, deposit INTEGER NOT NULL DEFAULT 0, withdrawal INTEGER NOT NULL DEFAULT 0, UNIQUE(shareholder,date))")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_daily_reports_shareholder_date ON daily_reports(shareholder,date)")
        }
    }

    fun shareholders(): List<String> {
        val out = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT name FROM shareholders ORDER BY id", null).use { c -> while (c.moveToNext()) out += c.getString(0) }
        return out
    }

    fun renameShareholder(oldName: String, newName: String): Boolean {
        if (newName.isBlank() || oldName == newName) return false
        writableDatabase.beginTransaction()
        return try {
            val check = readableDatabase.rawQuery("SELECT 1 FROM shareholders WHERE name=?", arrayOf(newName.trim()))
            val exists = check.use { it.moveToFirst() }
            if (exists) return false
            val v = ContentValues().apply { put("name", newName.trim()) }
            writableDatabase.update("shareholders", v, "name=?", arrayOf(oldName))
            val tv = ContentValues().apply { put("shareholder", newName.trim()) }
            writableDatabase.update("transactions", tv, "shareholder=?", arrayOf(oldName))
            writableDatabase.update("daily_reports", tv, "shareholder=?", arrayOf(oldName))
            writableDatabase.setTransactionSuccessful()
            true
        } finally { writableDatabase.endTransaction() }
    }

    fun insert(shareholder: String, symbol: String, type: String, qty: Long, price: Long, date: String) {
        val v = ContentValues().apply { put("shareholder", shareholder); put("symbol", symbol); put("type", type); put("qty", qty); put("price", price); put("date", date) }
        writableDatabase.insertOrThrow("transactions", null, v)
    }

    fun currentHolding(shareholder: String, symbol: String): Long {
        readableDatabase.rawQuery("SELECT COALESCE(SUM(CASE WHEN type='خرید' THEN qty ELSE -qty END),0) FROM transactions WHERE shareholder=? AND symbol=?", arrayOf(shareholder, symbol)).use { c -> return if (c.moveToFirst()) c.getLong(0) else 0L }
    }

    fun dailyTotals(shareholder: String, date: String): Pair<Long, Long> {
        var buy = 0L; var sell = 0L
        readableDatabase.rawQuery("SELECT type, COALESCE(SUM(qty*price),0) FROM transactions WHERE shareholder=? AND date=? GROUP BY type", arrayOf(shareholder,date)).use { c ->
            while (c.moveToNext()) if (c.getString(0) == "خرید") buy = c.getLong(1) else sell = c.getLong(1)
        }
        return buy to sell
    }

    fun saveDailyReport(shareholder: String, date: String, totalAssets: Long, portfolioValue: Long, portfolioPl: Long, dailyPl: Long, deposit: Long, withdrawal: Long) {
        val v = ContentValues().apply {
            put("shareholder", shareholder); put("date", date); put("total_assets", totalAssets); put("portfolio_value", portfolioValue)
            put("portfolio_pl", portfolioPl); put("daily_pl", dailyPl); put("deposit", deposit); put("withdrawal", withdrawal)
        }
        writableDatabase.insertWithOnConflict("daily_reports", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun dailyReport(shareholder: String, date: String): LongArray {
        readableDatabase.rawQuery("SELECT total_assets,portfolio_value,portfolio_pl,daily_pl,deposit,withdrawal FROM daily_reports WHERE shareholder=? AND date=?", arrayOf(shareholder,date)).use { c ->
            if (c.moveToFirst()) return LongArray(6) { i -> c.getLong(i) }
        }
        return LongArray(6)
    }

    fun recentFor(shareholder: String, limit: Int = 100): List<String> {
        val out = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT date,symbol,type,qty,price FROM transactions WHERE shareholder=? ORDER BY date DESC,id DESC LIMIT ?", arrayOf(shareholder,limit.toString())).use { c ->
            while (c.moveToNext()) out += "${c.getString(0)} | ${c.getString(1)} | ${c.getString(2)} | ${c.getLong(3)} | ${c.getLong(4)}"
        }
        return out
    }

    fun allFor(shareholder: String): List<Array<String>> {
        val out = mutableListOf<Array<String>>()
        readableDatabase.rawQuery("SELECT shareholder,symbol,type,qty,price,date FROM transactions WHERE shareholder=? ORDER BY date,id", arrayOf(shareholder)).use { c ->
            while (c.moveToNext()) out += arrayOf(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5))
        }
        return out
    }
}
