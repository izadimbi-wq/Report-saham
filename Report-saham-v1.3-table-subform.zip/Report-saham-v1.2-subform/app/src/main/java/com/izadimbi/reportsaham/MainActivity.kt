package com.izadimbi.reportsaham

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var db: PortfolioDb
    private lateinit var shareholder: Spinner
    private lateinit var month: EditText
    private lateinit var table: TableLayout
    private lateinit var status: TextView
    private lateinit var summaryAssets: TextView
    private lateinit var summaryPortfolio: TextView
    private lateinit var summaryPl: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = PortfolioDb(this)
        buildUi()
        refreshTable()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(TextView(this).apply {
            text = "گزارش سهام — جدول ماهانه سهامدار"
            textSize = 21f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 0, 0, 10)
        })

        shareholder = Spinner(this)
        shareholder.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, db.shareholders())
        addField(root, "سهامدار", shareholder)

        val controlRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        month = edit(currentMonth()).apply { inputType = InputType.TYPE_CLASS_TEXT; hint = "YYYY-MM" }
        controlRow.addView(month, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        controlRow.addView(Button(this).apply {
            text = "نمایش جدول"
            setOnClickListener { refreshTable() }
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(TextView(this).apply { text = "ماه گزارش (YYYY-MM)"; textSize = 13f })
        root.addView(controlRow)

        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
        }
        val assetsCard = summaryCard("ارزش کل دارایی").also { summaryAssets = it.second }
        val portfolioCard = summaryCard("ارزش کل پرتفوی").also { summaryPortfolio = it.second }
        val plCard = summaryCard("سود و زیان پرتفوی").also { summaryPl = it.second }
        summary.addView(assetsCard.first, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        summary.addView(portfolioCard.first, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        summary.addView(plCard.first, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(summary)

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actionRow.addView(Button(this).apply { text = "ویرایش نام سهامدار"; setOnClickListener { renameShareholder() } }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        actionRow.addView(Button(this).apply { text = "CSV"; setOnClickListener { exportCsv() } }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, .45f))
        actionRow.addView(Button(this).apply { text = "PDF"; setOnClickListener { exportPdf() } }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, .45f))
        root.addView(actionRow)

        val horizontal = HorizontalScrollView(this)
        val vertical = ScrollView(this).apply {
            isFillViewport = true
            setPadding(0, 0, 0, 4)
        }
        table = TableLayout(this).apply { isStretchAllColumns = false }
        vertical.addView(table, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        horizontal.addView(vertical, HorizontalScrollView.LayoutParams(HorizontalScrollView.LayoutParams.MATCH_PARENT, HorizontalScrollView.LayoutParams.MATCH_PARENT))
        root.addView(horizontal, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        status = TextView(this).apply { textSize = 13f; setPadding(0, 6, 0, 0) }
        root.addView(status)

        shareholder.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { refreshTable() }
        }
        setContentView(root)
    }

    private fun summaryCard(title: String): Pair<LinearLayout, TextView> {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(6, 6, 6, 6)
            setBackgroundResource(android.R.drawable.editbox_background)
        }
        card.addView(TextView(this).apply {
            text = title
            textSize = 11f
            gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD)
        })
        val value = TextView(this).apply {
            text = "—"
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, 5, 0, 0)
        }
        card.addView(value)
        return card to value
    }

    private fun refreshTable() {
        if (!::table.isInitialized || !::shareholder.isInitialized) return
        val ym = month.text.toString().trim()
        if (!Regex("\\d{4}-\\d{2}").matches(ym)) {
            status.text = "ماه را به شکل YYYY-MM وارد کنید."
            return
        }
        refreshSummary()
        table.removeAllViews()
        val headers = listOf("تاریخ", "موجودی نقدی", "سود و زیان روز", "واریز", "برداشت", "خرید", "فروش")
        val header = TableRow(this)
        headers.forEach { h -> header.addView(cell(h, true)) }
        table.addView(header)
        for (day in 1..31) {
            val date = "$ym-${day.toString().padStart(2, '0')}"
            val report = db.dailyReport(shareholder.selectedItem.toString(), date)
            val totals = db.dailyTotals(shareholder.selectedItem.toString(), date)
            val cash = db.cashBalance(shareholder.selectedItem.toString(), date)
            val values = listOf(
                day.toString(), money(cash), money(report[3]), money(report[4]), money(report[5]), money(totals.first), money(totals.second)
            )
            val row = TableRow(this)
            values.forEach { v -> row.addView(cell(v, false)) }
            row.setOnClickListener { openDayDialog(date) }
            table.addView(row)
        }
        status.text = "۳۱ روز نمایش داده شد. برای ویرایش هر روز روی ردیف آن بزنید."
    }

    private fun refreshSummary() {
        val who = shareholder.selectedItem?.toString() ?: return
        val latest = db.latestDailyReport(who)
        val latestDate = latest.first
        val report = latest.second
        val cash = if (latestDate.isBlank()) 0L else db.cashBalance(who, latestDate)
        // Market prices are not yet stored in the app, so portfolio value and portfolio P/L
        // come from the latest saved daily report. Total assets is derived from portfolio value + cash.
        summaryAssets.text = if (latestDate.isBlank()) "—" else money(report[1] + cash)
        summaryPortfolio.text = if (latestDate.isBlank()) "—" else money(report[1])
        summaryPl.text = if (latestDate.isBlank()) "—" else money(report[2])
    }

    private fun cell(text: String, header: Boolean): TextView = TextView(this).apply {
        this.text = text
        textSize = if (header) 12f else 11f
        setTypeface(null, if (header) Typeface.BOLD else Typeface.NORMAL)
        setTextColor(Color.BLACK)
        gravity = Gravity.CENTER
        setPadding(12, 14, 12, 14)
        minWidth = if (header) 120 else 105
        setBackgroundResource(android.R.drawable.editbox_background)
    }

    private fun openDayDialog(date: String) {
        val report = db.dailyReport(shareholder.selectedItem.toString(), date)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 6, 18, 0) }
        val formScroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        formScroll.addView(box)

        val fields = listOf("ارزش کل دارایی", "ارزش کل پرتفوی", "سود و زیان پرتفوی", "سود و زیان روز", "واریز", "برداشت")
        val edits = fields.mapIndexed { i, label ->
            val e = edit(if (report[i] == 0L) "" else report[i].toString()).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
                hint = label
            }
            box.addView(TextView(this).apply { text = label; textSize = 12f })
            box.addView(e)
            e
        }

        val tradeButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tradeButtons.addView(Button(this).apply {
            text = "خرید — Subform"
            setOnClickListener { openTradeSubform("خرید", date) }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        tradeButtons.addView(Button(this).apply {
            text = "فروش — Subform"
            setOnClickListener { openTradeSubform("فروش", date) }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(tradeButtons)

        content.addView(formScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        lateinit var dialog: AlertDialog
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 8, 0, 8) }
        val cancel = Button(this).apply { text = "انصراف"; setOnClickListener { dialog.dismiss() } }
        val save = Button(this).apply {
            text = "ثبت"
            setOnClickListener {
                val values = edits.map { it.text.toString().toLongOrNull() ?: 0L }
                db.saveDailyReport(shareholder.selectedItem.toString(), date, values[0], values[1], values[2], values[3], values[4], values[5])
                status.text = "اطلاعات روز $date ثبت شد."
                refreshTable()
                dialog.dismiss()
            }
        }
        buttons.addView(cancel, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        buttons.addView(save, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        content.addView(buttons)
        dialog = AlertDialog.Builder(this).setTitle("گزارش روز $date").setView(content).create()
        dialog.show()
    }

    private fun openTradeSubform(tradeType: String, selectedDate: String) {
        val shareholderName = shareholder.selectedItem.toString()
        val existing = db.transactionsFor(shareholderName, selectedDate, tradeType)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 4, 12, 0) }
        val formScroll = ScrollView(this)
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        form.addView(TextView(this).apply {
            text = "$tradeType — معاملات $selectedDate"
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 0, 0, 8)
        })
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        form.addView(rows)
        val subStatus = TextView(this).apply { textSize = 12f; setTextColor(Color.RED); setPadding(0, 6, 0, 6) }
        form.addView(subStatus)

        fun addRow(symbolValue: String = "", qtyValue: String = "", priceValue: String = "") {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 3, 0, 3) }
            val symbol = EditText(this).apply { hint = "نماد"; setText(symbolValue); inputType = InputType.TYPE_CLASS_TEXT }
            val qty = EditText(this).apply { hint = "تعداد"; setText(qtyValue); inputType = InputType.TYPE_CLASS_NUMBER }
            val price = EditText(this).apply { hint = "قیمت"; setText(priceValue); inputType = InputType.TYPE_CLASS_NUMBER }
            val remove = Button(this).apply { text = "حذف" }
            row.addView(symbol, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.1f))
            row.addView(qty, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(price, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(remove, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, .65f))
            remove.setOnClickListener { rows.removeView(row) }
            rows.addView(row)
        }

        if (existing.isEmpty()) addRow("فولاد") else existing.forEach { addRow(it[1], it[2], it[3]) }
        form.addView(Button(this).apply { text = "+ افزودن ردیف معامله"; setOnClickListener { addRow() } })
        formScroll.addView(form)
        content.addView(formScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        lateinit var dialog: AlertDialog
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 8, 0, 8) }
        val cancel = Button(this).apply { text = "انصراف"; setOnClickListener { dialog.dismiss() } }
        val save = Button(this).apply {
            text = "ثبت معاملات"
            setOnClickListener {
                val trades = mutableListOf<Triple<String, Long, Long>>()
                for (i in 0 until rows.childCount) {
                    val r = rows.getChildAt(i) as LinearLayout
                    val s = (r.getChildAt(0) as EditText).text.toString().trim().uppercase(Locale.US)
                    val q = (r.getChildAt(1) as EditText).text.toString().trim().toLongOrNull()
                    val p = (r.getChildAt(2) as EditText).text.toString().trim().toLongOrNull()
                    if (s.isBlank() || q == null || q <= 0L || p == null || p < 0L) {
                        subStatus.text = "اطلاعات این ردیف کامل نیست. نماد، تعداد و قیمت را وارد کنید."
                        return@setOnClickListener
                    }
                    trades += Triple(s, q, p)
                }
                val error = db.replaceTrades(shareholderName, selectedDate, tradeType, trades)
                if (error != null) {
                    subStatus.text = error
                    return@setOnClickListener
                }
                status.text = "${trades.size} معامله $tradeType برای $selectedDate ثبت شد."
                refreshTable()
                dialog.dismiss()
            }
        }
        buttons.addView(cancel, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        buttons.addView(save, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        content.addView(buttons)
        dialog = AlertDialog.Builder(this).setTitle("Subform $tradeType").setView(content).create()
        dialog.show()
    }

    private fun renameShareholder() {
        val oldName = shareholder.selectedItem?.toString() ?: return
        val e = edit(oldName)
        AlertDialog.Builder(this).setTitle("ویرایش نام سهامدار").setView(e).setNegativeButton("انصراف", null).setPositiveButton("ذخیره") { _, _ ->
            val newName = e.text.toString().trim()
            if (newName.isBlank()) { status.text = "نام سهامدار نمی‌تواند خالی باشد."; return@setPositiveButton }
            if (!db.renameShareholder(oldName, newName)) { status.text = "این نام قبلاً وجود دارد یا تغییری انجام نشده است."; return@setPositiveButton }
            shareholder.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, db.shareholders())
            status.text = "نام سهامدار به «$newName» تغییر کرد و سوابق قبلی حفظ شد."
            refreshTable()
        }.show()
    }

    private fun addField(root: LinearLayout, label: String, view: View) { root.addView(TextView(this).apply { text = label; textSize = 13f }); root.addView(view, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)) }
    private fun edit(value: String) = EditText(this).apply { setText(value); inputType = InputType.TYPE_CLASS_TEXT }
    private fun money(v: Long): String = if (v == 0L) "—" else String.format(Locale.US, "%,d", v)
    private fun currentMonth() = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun exportCsv() {
        val who = shareholder.selectedItem.toString()
        val csv = buildString { append("سهامدار,نماد,نوع,تعداد,قیمت,تاریخ\n"); db.allFor(who).forEach { r -> append(r.joinToString(",") { v -> "\"" + v.replace("\"", "\"\"") + "\"" }).append("\n") } }
        val v = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, "Report-saham-$who-${today()}.csv"); put(MediaStore.Downloads.MIME_TYPE, "text/csv"); put(MediaStore.Downloads.RELATIVE_PATH, "Download") }
        contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)?.let { uri -> contentResolver.openOutputStream(uri)?.use { it.write(byteArrayOf(0xEF.toByte(),0xBB.toByte(),0xBF.toByte())); it.write(csv.toByteArray(Charsets.UTF_8)) }; status.text = "گزارش CSV سهامدار $who ذخیره شد." }
    }

    private fun exportPdf() {
        val who = shareholder.selectedItem.toString(); val doc = PdfDocument(); val page = doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create()); val c = page.canvas
        val p = android.graphics.Paint().apply { textSize = 11f; color = Color.BLACK }; var y = 40f
        c.drawText("Report Saham - $who", 30f, y, p); y += 25f
        db.allFor(who).take(35).forEach { c.drawText(it.joinToString(" | ").take(100), 30f, y, p); y += 18f }
        doc.finishPage(page)
        val v = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, "Report-saham-$who-${today()}.pdf"); put(MediaStore.Downloads.MIME_TYPE, "application/pdf"); put(MediaStore.Downloads.RELATIVE_PATH, "Download") }
        contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)?.let { uri -> contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) }; status.text = "گزارش PDF سهامدار $who ذخیره شد." }; doc.close()
    }
}
