package com.izadimbi.reportsaham

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var db: PortfolioDb
    private lateinit var shareholder: Spinner
    private lateinit var month: EditText
    private lateinit var table: TableLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = PortfolioDb(this)
        buildUi()
        refreshTable()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(TextView(this).apply {
            text = "گزارش سهام — جدول ماهانه سهامدار"
            textSize = 21f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 0, 0, 12)
        })

        shareholder = Spinner(this)
        shareholder.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, db.shareholders())
        addField(root, "سهامدار", shareholder)

        val controlRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        month = edit(currentMonth()).apply { inputType = InputType.TYPE_CLASS_TEXT; hint = "YYYY-MM" }
        controlRow.addView(month, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        controlRow.addView(Button(this).apply {
            text = "نمایش جدول"
            setOnClickListener { refreshTable() }
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(TextView(this).apply { text = "ماه گزارش (YYYY-MM)"; textSize = 13f })
        root.addView(controlRow)

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actionRow.addView(Button(this).apply { text = "ویرایش نام سهامدار"; setOnClickListener { renameShareholder() } }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        actionRow.addView(Button(this).apply { text = "CSV"; setOnClickListener { exportCsv() } }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, .45f))
        actionRow.addView(Button(this).apply { text = "PDF"; setOnClickListener { exportPdf() } }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, .45f))
        root.addView(actionRow)

        val horizontal = HorizontalScrollView(this)
        table = TableLayout(this).apply { isStretchAllColumns = false }
        horizontal.addView(table)
        root.addView(horizontal, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        status = TextView(this).apply { textSize = 13f; setPadding(0, 8, 0, 0) }
        root.addView(status)

        shareholder.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { refreshTable() }
        }
        setContentView(root)
    }

    private fun refreshTable() {
        if (!::table.isInitialized || !::shareholder.isInitialized) return
        val ym = month.text.toString().trim()
        if (!Regex("\\d{4}-\\d{2}").matches(ym)) {
            status.text = "ماه را به شکل YYYY-MM وارد کنید."
            return
        }
        table.removeAllViews()
        val headers = listOf("تاریخ", "ارزش کل دارایی", "ارزش کل پرتفوی", "سود و زیان پرتفوی", "سود و زیان روز", "واریز", "برداشت", "خرید", "فروش")
        val header = TableRow(this)
        headers.forEach { h -> header.addView(cell(h, true)) }
        table.addView(header)
        for (day in 1..31) {
            val date = "$ym-${day.toString().padStart(2, '0')}"
            val report = db.dailyReport(shareholder.selectedItem.toString(), date)
            val totals = db.dailyTotals(shareholder.selectedItem.toString(), date)
            val values = listOf(
                day.toString(), money(report[0]), money(report[1]), money(report[2]), money(report[3]),
                money(report[4]), money(report[5]), money(totals.first), money(totals.second)
            )
            val row = TableRow(this)
            values.forEach { v -> row.addView(cell(v, false)) }
            row.setOnClickListener { openDayDialog(date) }
            table.addView(row)
        }
        status.text = "برای ویرایش اطلاعات هر روز، روی همان ردیف بزنید. خرید و فروش از Subform محاسبه می‌شوند."
    }

    private fun cell(text: String, header: Boolean): TextView = TextView(this).apply {
        this.text = text
        textSize = if (header) 12f else 11f
        setTypeface(null, if (header) Typeface.BOLD else Typeface.NORMAL)
        setTextColor(Color.BLACK)
        gravity = Gravity.CENTER
        setPadding(12, 14, 12, 14)
        minWidth = if (header) 120 else 105
        setBackgroundResource(android.R.drawable.editbox_background)
    }

    private fun openDayDialog(date: String) {
        val report = db.dailyReport(shareholder.selectedItem.toString(), date)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 6, 18, 0) }
        val fields = listOf("ارزش کل دارایی", "ارزش کل پرتفوی", "سود و زیان پرتفوی", "سود و زیان روز", "واریز", "برداشت")
        val edits = fields.mapIndexed { i, label ->
            val e = edit(if (report[i] == 0L) "" else report[i].toString()).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED; hint = label }
            box.addView(TextView(this).apply { text = label; textSize = 12f })
            box.addView(e)
            e
        }
        val tradeButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tradeButtons.addView(Button(this).apply { text = "خرید — Subform"; setOnClickListener { openTradeSubform("خرید", date) } }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        tradeButtons.addView(Button(this).apply { text = "فروش — Subform"; setOnClickListener { openTradeSubform("فروش", date) } }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(tradeButtons)
        AlertDialog.Builder(this).setTitle("گزارش روز $date").setView(ScrollView(this).apply { addView(box) })
            .setNegativeButton("انصراف", null)
            .setPositiveButton("ذخیره") { _, _ ->
                val values = edits.map { it.text.toString().toLongOrNull() ?: 0L }
                db.saveDailyReport(shareholder.selectedItem.toString(), date, values[0], values[1], values[2], values[3], values[4], values[5])
                refreshTable()
            }.show()
    }

    private fun openTradeSubform(tradeType: String, selectedDate: String) {
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 4, 12, 4) }
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        container.addView(TextView(this).apply { text = "$tradeType — جزئیات معاملات $selectedDate"; textSize = 17f; setTypeface(null, Typeface.BOLD); setPadding(0, 0, 0, 12) })
        container.addView(rows)
        fun addRow() {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 4, 0, 4) }
            val symbol = EditText(this).apply { hint = "نماد"; setText("فولاد"); inputType = InputType.TYPE_CLASS_TEXT }
            val qty = EditText(this).apply { hint = "تعداد"; inputType = InputType.TYPE_CLASS_NUMBER }
            val price = EditText(this).apply { hint = "قیمت"; inputType = InputType.TYPE_CLASS_NUMBER }
            val remove = Button(this).apply { text = "حذف" }
            row.addView(symbol, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.1f))
            row.addView(qty, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(price, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(remove, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, .65f))
            remove.setOnClickListener { rows.removeView(row) }
            rows.addView(row)
        }
        addRow()
        container.addView(Button(this).apply { text = "+ افزودن ردیف معامله"; setOnClickListener { addRow() } })
        val scroll = ScrollView(this).apply { addView(container) }
        val dialog = AlertDialog.Builder(this).setTitle("Subform ثبت $tradeType").setView(scroll).setNegativeButton("انصراف", null).create()
        dialog.setButton(AlertDialog.BUTTON_POSITIVE, "ثبت گزارش") { _, _ ->
            var count = 0; var error: String? = null
            for (i in 0 until rows.childCount) {
                val r = rows.getChildAt(i) as LinearLayout
                val s = (r.getChildAt(0) as EditText).text.toString().trim().uppercase(Locale.US)
                val q = (r.getChildAt(1) as EditText).text.toString().toLongOrNull()
                val p = (r.getChildAt(2) as EditText).text.toString().toLongOrNull()
                if (s.isBlank() || q == null || q <= 0 || p == null || p < 0) { error = "یکی از ردیف‌ها اطلاعات کامل ندارد."; break }
                if (tradeType == "فروش") {
                    val available = db.currentHolding(shareholder.selectedItem.toString(), s)
                    if (q > available) { error = "فروش $s ثبت نشد؛ موجودی فعلی: $available سهم"; break }
                }
                db.insert(shareholder.selectedItem.toString(), s, tradeType, q, p, selectedDate); count++
            }
            status.text = error ?: "$count معامله $tradeType برای ${shareholder.selectedItem} در تاریخ $selectedDate ثبت شد."
            refreshTable()
        }
        dialog.show()
    }

    private fun renameShareholder() {
        val oldName = shareholder.selectedItem?.toString() ?: return
        val e = edit(oldName)
        AlertDialog.Builder(this).setTitle("ویرایش نام سهامدار").setView(e).setNegativeButton("انصراف", null).setPositiveButton("ذخیره") { _, _ ->
            val newName = e.text.toString().trim()
            if (newName.isBlank()) { status.text = "نام سهامدار نمی‌تواند خالی باشد."; return@setPositiveButton }
            if (!db.renameShareholder(oldName, newName)) { status.text = "این نام قبلاً وجود دارد یا تغییری انجام نشده است."; return@setPositiveButton }
            shareholder.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, db.shareholders())
            status.text = "نام سهامدار به «$newName» تغییر کرد و سوابق قبلی حفظ شد."
            refreshTable()
        }.show()
    }

    private fun addField(root: LinearLayout, label: String, view: View) { root.addView(TextView(this).apply { text = label; textSize = 13f }); root.addView(view, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)) }
    private fun edit(value: String) = EditText(this).apply { setText(value); inputType = InputType.TYPE_CLASS_TEXT }
    private fun money(v: Long): String = if (v == 0L) "—" else String.format(Locale.US, "%,d", v)
    private fun currentMonth() = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun exportCsv() {
        val who = shareholder.selectedItem.toString()
        val csv = buildString { append("سهامدار,نماد,نوع,تعداد,قیمت,تاریخ\n"); db.allFor(who).forEach { r -> append(r.joinToString(",") { v -> "\"" + v.replace("\"", "\"\"") + "\"" }).append("\n") } }
        val v = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, "Report-saham-$who-${today()}.csv"); put(MediaStore.Downloads.MIME_TYPE, "text/csv"); put(MediaStore.Downloads.RELATIVE_PATH, "Download") }
        contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)?.let { uri -> contentResolver.openOutputStream(uri)?.use { it.write(byteArrayOf(0xEF.toByte(),0xBB.toByte(),0xBF.toByte())); it.write(csv.toByteArray(Charsets.UTF_8)) }; status.text = "گزارش CSV سهامدار $who ذخیره شد." }
    }

    private fun exportPdf() {
        val who = shareholder.selectedItem.toString(); val doc = PdfDocument(); val page = doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create()); val c = page.canvas
        val p = android.graphics.Paint().apply { textSize = 11f; color = Color.BLACK }; var y = 40f
        c.drawText("Report Saham - $who", 30f, y, p); y += 25f
        db.allFor(who).take(35).forEach { c.drawText(it.joinToString(" | ").take(100), 30f, y, p); y += 18f }
        doc.finishPage(page)
        val v = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, "Report-saham-$who-${today()}.pdf"); put(MediaStore.Downloads.MIME_TYPE, "application/pdf"); put(MediaStore.Downloads.RELATIVE_PATH, "Download") }
        contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)?.let { uri -> contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) }; status.text = "گزارش PDF سهامدار $who ذخیره شد." }; doc.close()
    }
}
