package com.izadimbi.reportsaham

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var db: PortfolioDb
    private lateinit var shareholder: Spinner
    private lateinit var month: EditText
    private lateinit var table: TableLayout
    private lateinit var status: TextView
    private lateinit var summaryAssets: TextView
    private lateinit var summaryPortfolio: TextView
    private lateinit var summaryPl: TextView
    private lateinit var portfolioTable: TableLayout
    private lateinit var portfolioDate: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = PortfolioDb(this)
        buildUi()
        refreshTable()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(TextView(this).apply {
            text = "گزارش سهام — جدول ماهانه سهامدار"
            textSize = 21f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 0, 0, 10)
        })

        shareholder = Spinner(this)
        shareholder.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, db.shareholders())
        addField(root, "سهامدار", shareholder)

        val controlRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        month = edit(toPersianDigits(currentMonth())).apply { inputType = InputType.TYPE_CLASS_TEXT; hint = "۱۴۰۵-۰۹" }
        controlRow.addView(month, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        controlRow.addView(Button(this).apply {
            text = "نمایش جدول"
            setOnClickListener { refreshTable() }
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(TextView(this).apply { text = "ماه گزارش (YYYY-MM)"; textSize = 13f })
        root.addView(controlRow)

        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
        }
        val assetsCard = summaryCard("ارزش کل دارایی").also { summaryAssets = it.second }
        val portfolioCard = summaryCard("ارزش کل پرتفوی").also { summaryPortfolio = it.second }
        val plCard = summaryCard("سود و زیان پرتفوی").also { summaryPl = it.second }
        summary.addView(assetsCard.first, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        summary.addView(portfolioCard.first, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        summary.addView(plCard.first, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(summary)

        portfolioDate = TextView(this).apply {
            textSize = 13f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 6, 0, 4)
        }
        root.addView(portfolioDate)

        // پرتفوی: اسکرول عمودی برای همه ردیف‌ها + اسکرول افقی برای همه ستون‌ها
        val portfolioVerticalScroll = ScrollView(this).apply {
            isFillViewport = true
        }
        val portfolioScroll = HorizontalScrollView(this)
        portfolioTable = TableLayout(this).apply { isStretchAllColumns = false }
        portfolioScroll.addView(
            portfolioTable,
            android.view.ViewGroup.LayoutParams(
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        portfolioVerticalScroll.addView(
            portfolioScroll,
            android.view.ViewGroup.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        root.addView(
            portfolioVerticalScroll,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                0.8f
            )
        )

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actionRow.addView(Button(this).apply { text = "ویرایش نام سهامدار"; setOnClickListener { renameShareholder() } }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        actionRow.addView(Button(this).apply { text = "ورود پرتفوی Excel"; setOnClickListener { pickExcel(REQUEST_PORTFOLIO) } }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        actionRow.addView(Button(this).apply { text = "ورود سفارشات Excel"; setOnClickListener { pickExcel(REQUEST_ORDERS) } }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(actionRow)
        root.addView(Button(this).apply {
            text = "سوابق پرتفوی"
            setOnClickListener { showPortfolioHistory() }
        })
        val exportRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        exportRow.addView(Button(this).apply { text = "CSV"; setOnClickListener { exportCsv() } }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, .5f))
        exportRow.addView(Button(this).apply { text = "PDF"; setOnClickListener { exportPdf() } }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, .5f))
        root.addView(exportRow)

        val horizontal = HorizontalScrollView(this)
        val vertical = ScrollView(this).apply {
            isFillViewport = true
            setPadding(0, 0, 0, 4)
        }
        table = TableLayout(this).apply { isStretchAllColumns = false }
        vertical.addView(table, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        horizontal.addView(vertical, android.view.ViewGroup.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(horizontal, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        status = TextView(this).apply { textSize = 13f; setPadding(0, 6, 0, 0) }
        root.addView(status)

        shareholder.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { refreshTable() }
        }
        setContentView(root)
    }

    private fun summaryCard(title: String): Pair<LinearLayout, TextView> {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(6, 6, 6, 6)
            setBackgroundResource(android.R.drawable.editbox_background)
        }
        card.addView(TextView(this).apply {
            text = title
            textSize = 11f
            gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD)
        })
        val value = TextView(this).apply {
            text = "—"
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, 5, 0, 0)
        }
        card.addView(value)
        return card to value
    }

    private fun refreshTable() {
        if (!::table.isInitialized || !::shareholder.isInitialized) return
        val ym = normalizeDigits(month.text.toString().trim()).replace('/', '-')
        if (!Regex("\\d{4}-\\d{2}").matches(ym) || ym.substring(0, 4).toInt() < 1300 || ym.substring(0, 4).toInt() > 1600) {
            status.text = "ماه را به شکل ۱۴۰۵-۰۹ وارد کنید."
            return
        }
        month.setText(toPersianDigits(ym))
        refreshSummary()
        refreshPortfolioTable()
        table.removeAllViews()
        val headers = listOf("تاریخ", "موجودی نقدی", "سود و زیان روز", "واریز", "برداشت", "خرید", "فروش")
        val header = TableRow(this)
        headers.forEach { h -> header.addView(cell(h, true)) }
        table.addView(header)
        val days = jalaliMonthDays(ym.substring(0, 4).toInt(), ym.substring(5, 7).toInt())
        for (day in 1..days) {
            val date = "$ym-${day.toString().padStart(2, '0')}"
            val who = shareholder.selectedItem.toString()
            val report = db.dailyReport(who, date)
            val totals = db.dailyTotals(who, date)
            val cash = db.cashBalance(who, date)
            val hasSnapshot = db.hasPortfolioSnapshot(who, date)
            val snapshot = db.portfolioSummary(who, date)
            val portfolioValue = snapshot[0]
            val portfolioPl = if (hasSnapshot) snapshot[0] - snapshot[1] else 0L
            val previousDate = db.previousPortfolioDate(who, date)
            val previous = if (previousDate.isBlank()) LongArray(3) else db.portfolioSummary(who, previousDate)
            val dailyPl = if (!hasSnapshot) 0L else if (previousDate.isBlank()) portfolioPl else (portfolioValue - previous[0]) - totals.first + totals.second
            val row = TableRow(this)
            row.addView(cell(toPersianDigits(day.toString()), false))
            row.addView(financialCell(cash, false))
            row.addView(financialCell(dailyPl, false))
            row.addView(financialCell(report[4], false))
            row.addView(financialCell(report[5], false))
            row.addView(financialCell(totals.first, false))
            row.addView(financialCell(totals.second, false))
            row.setOnClickListener { openDayDialog(date) }
            table.addView(row)
        }
        status.text = "${toPersianDigits(days.toString())} روز نمایش داده شد. برای ویرایش هر روز روی ردیف آن بزنید."
    }

    private fun refreshPortfolioTable() {
        if (!::portfolioTable.isInitialized || !::shareholder.isInitialized) return
        val who = shareholder.selectedItem?.toString() ?: return
        val latest = db.portfolioLatestRows(who)
        renderPortfolioForDate(latest.first)
    }

    private fun renderPortfolioForDate(date: String) {
        portfolioTable.removeAllViews()
        portfolioDate.text = if (date.isBlank()) "پرتفوی واردشده: اطلاعاتی ثبت نشده است" else "پرتفوی واردشده — تاریخ: ${toPersianDate(date)}"
        val headers = listOf("نام نماد", "تعداد دارایی", "تعداد سهام جایزه", "تعداد حق تقدم", "آخرین قیمت", "قیمت میانگین کل خرید با لحاظ کارمزد", "ارزش نماد")
        val header = TableRow(this)
        headers.forEach { header.addView(cell(it, true)) }
        portfolioTable.addView(header)
        if (date.isBlank()) {
            val row = TableRow(this)
            row.addView(cell("برای این سهامدار پرتفویی وارد نشده است.", false))
            portfolioTable.addView(row)
            return
        }
        val rows = db.portfolioRows(shareholder.selectedItem.toString(), date)
        if (rows.isEmpty()) {
            val row = TableRow(this)
            row.addView(cell("برای این تاریخ پرتفویی ثبت نشده است.", false))
            portfolioTable.addView(row)
            return
        }
        rows.forEach { r ->
            val qty = r[1].toLongOrNull() ?: 0L
            val bonus = r[2].toLongOrNull() ?: 0L
            val right = r[3].toLongOrNull() ?: 0L
            val last = r[4].toLongOrNull() ?: 0L
            val value = qty * last
            val row = TableRow(this)
            row.addView(cell(r[0], false))
            row.addView(countCell(qty, false))
            row.addView(countCell(bonus, false))
            row.addView(countCell(right, false))
            row.addView(financialCell(last, false))
            row.addView(financialCell(r[5].toDoubleOrNull()?.toLong() ?: 0L, false))
            row.addView(financialCell(value, false))
            portfolioTable.addView(row)
        }
    }

    private fun showPortfolioHistory() {
        val who = shareholder.selectedItem?.toString() ?: return
        val dates = db.portfolioSnapshotDates(who)
        if (dates.isEmpty()) {
            status.text = "برای این سهامدار سابقه پرتفویی ثبت نشده است."
            return
        }
        val labels = dates.map { toPersianDate(it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("سوابق پرتفوی — $who")
            .setItems(labels) { _, which -> renderPortfolioForDate(dates[which]) }
            .setNegativeButton("بستن", null)
            .show()
    }

    private fun refreshSummary() {
        val who = shareholder.selectedItem?.toString() ?: return
        val latestDate = db.latestPortfolioDate(who)
        if (latestDate.isBlank()) {
            summaryAssets.text = "—"; summaryPortfolio.text = "—"; summaryPl.text = "—"
            return
        }
        val p = db.portfolioSummary(who, latestDate)
        val cash = db.cashBalance(who, latestDate)
        val portfolioValue = p[0]
        val cost = p[1]
        // ارزش کل دارایی = موجودی نقدی + ارزش کل پرتفوی
        val totalAssets = cash + portfolioValue
        summaryAssets.text = money(totalAssets)
        summaryPortfolio.text = money(portfolioValue)
        val portfolioPl = portfolioValue - cost
        summaryPl.text = money(portfolioPl)
        summaryPl.setTextColor(when { portfolioPl > 0L -> Color.rgb(0, 128, 0); portfolioPl < 0L -> Color.rgb(200, 0, 0); else -> Color.BLACK })
    }

    private fun cell(text: String, header: Boolean): TextView = TextView(this).apply {
        this.text = text
        textSize = if (header) 12f else 11f
        setTypeface(null, if (header) Typeface.BOLD else Typeface.NORMAL)
        setTextColor(Color.BLACK)
        gravity = Gravity.CENTER
        setPadding(12, 14, 12, 14)
        minWidth = if (header) 120 else 105
        setBackgroundResource(android.R.drawable.editbox_background)
    }

    private fun financialCell(value: Long, header: Boolean): TextView = cell(money(value), header).apply {
        setTextColor(when { value > 0L -> Color.rgb(0, 128, 0); value < 0L -> Color.rgb(200, 0, 0); else -> Color.BLACK })
    }

    private fun countCell(value: Long, header: Boolean): TextView = cell(toPersianDigits(String.format(Locale.US, "%,d", value)), header).apply {
        setTextColor(when { value > 0L -> Color.rgb(0, 128, 0); value < 0L -> Color.rgb(200, 0, 0); else -> Color.BLACK })
    }

    private fun openDayDialog(date: String) {
        val report = db.dailyReport(shareholder.selectedItem.toString(), date)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 6, 18, 0) }
        val formScroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        formScroll.addView(box)

        val who = shareholder.selectedItem.toString()
        val cashNow = db.cashBalance(who, date)
        val portfolioValueNow = db.portfolioSummary(who, date)[0]
        val totalAssetsNow = cashNow + portfolioValueNow

        fun readOnlyValue(label: String, value: Long): TextView {
            box.addView(TextView(this).apply { text = label; textSize = 12f })
            return TextView(this).apply {
                text = money(value)
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(12, 10, 12, 10)
                setTextColor(when { value > 0L -> Color.rgb(0, 128, 0); value < 0L -> Color.rgb(200, 0, 0); else -> Color.BLACK })
                setBackgroundResource(android.R.drawable.editbox_background)
            }.also { box.addView(it) }
        }

        box.addView(TextView(this).apply { text = "موجودی نقدی (ریال)"; textSize = 12f })
        val cashEdit = edit(if (cashNow == 0L) "" else cashNow.toString()).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            hint = "موجودی نقدی همان روز"
        }
        box.addView(cashEdit)
        readOnlyValue("ارزش کل پرتفوی", portfolioValueNow)
        readOnlyValue("ارزش کل دارایی", totalAssetsNow)

        val snapshot = db.portfolioSummary(who, date)
        val portfolioPlNow = snapshot[0] - snapshot[1]
        val previousDate = db.previousPortfolioDate(who, date)
        val previousSnapshot = if (previousDate.isBlank()) LongArray(3) else db.portfolioSummary(who, previousDate)
        val dayTotals = db.dailyTotals(who, date)
        val dailyPlNow = if (previousDate.isBlank()) portfolioPlNow else (snapshot[0] - previousSnapshot[0]) - dayTotals.first + dayTotals.second
        readOnlyValue("سود و زیان پرتفوی", portfolioPlNow)
        readOnlyValue("سود و زیان روز", dailyPlNow)

        val fields = listOf("واریز", "برداشت")
        val edits = fields.mapIndexed { j, label ->
            val i = j + 4
            val e = edit(if (report[i] == 0L) "" else report[i].toString()).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
                hint = label
            }
            box.addView(TextView(this).apply { text = label; textSize = 12f })
            box.addView(e)
            e
        }

        val tradeButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tradeButtons.addView(Button(this).apply {
            text = "خرید — Subform"
            setOnClickListener { openTradeSubform("خرید", date) }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        tradeButtons.addView(Button(this).apply {
            text = "فروش — Subform"
            setOnClickListener { openTradeSubform("فروش", date) }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(tradeButtons)

        content.addView(formScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        lateinit var dialog: AlertDialog
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 8, 0, 8) }
        val cancel = Button(this).apply { text = "انصراف"; setOnClickListener { dialog.dismiss() } }
        val save = Button(this).apply {
            text = "ثبت"
            setOnClickListener {
                val snapshot = db.portfolioSummary(who, date)
                val portfolioValue = snapshot[0]
                val portfolioPl = snapshot[0] - snapshot[1]
                val previousDate = db.previousPortfolioDate(who, date)
                val previousSnapshot = if (previousDate.isBlank()) LongArray(3) else db.portfolioSummary(who, previousDate)
                val dayTotals = db.dailyTotals(who, date)
                val dailyPl = if (previousDate.isBlank()) portfolioPl else (portfolioValue - previousSnapshot[0]) - dayTotals.first + dayTotals.second
                val cash = normalizeDigits(cashEdit.text.toString()).replace(",", "").replace("٬", "").toLongOrNull() ?: 0L
                val totalAssets = cash + portfolioValue
                val values = edits.map { normalizeDigits(it.text.toString()).replace(",", "").replace("٬", "").toLongOrNull() ?: 0L }
                db.saveDailyReport(who, date, cash, totalAssets, portfolioValue, portfolioPl, dailyPl, values[0], values[1])
                status.text = "اطلاعات روز ${toPersianDate(date)} ثبت شد."
                refreshTable()
                dialog.dismiss()
            }
        }
        buttons.addView(cancel, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        buttons.addView(save, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        content.addView(buttons)
        dialog = AlertDialog.Builder(this).setTitle("گزارش روز ${toPersianDate(date)}").setView(content).create()
        dialog.show()
    }

    private fun openTradeSubform(tradeType: String, selectedDate: String) {
        val shareholderName = shareholder.selectedItem.toString()
        val existing = db.transactionsFor(shareholderName, selectedDate, tradeType)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 4, 12, 0) }
        val formScroll = ScrollView(this)
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        form.addView(TextView(this).apply {
            text = "$tradeType — معاملات ${toPersianDate(selectedDate)}"
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 0, 0, 8)
        })
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        form.addView(rows)
        val subStatus = TextView(this).apply { textSize = 12f; setTextColor(Color.RED); setPadding(0, 6, 0, 6) }
        form.addView(subStatus)

        fun addRow(symbolValue: String = "", qtyValue: String = "", priceValue: String = "") {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 3, 0, 3) }
            val symbol = EditText(this).apply { hint = "نماد"; setText(symbolValue); inputType = InputType.TYPE_CLASS_TEXT }
            val qty = EditText(this).apply { hint = "تعداد"; setText(qtyValue); inputType = InputType.TYPE_CLASS_NUMBER }
            val price = EditText(this).apply { hint = "قیمت"; setText(priceValue); inputType = InputType.TYPE_CLASS_NUMBER }
            val remove = Button(this).apply { text = "حذف" }
            row.addView(symbol, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.1f))
            row.addView(qty, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(price, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(remove, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, .65f))
            remove.setOnClickListener { rows.removeView(row) }
            rows.addView(row)
        }

        if (existing.isEmpty()) addRow() else existing.forEach { addRow(it[1], it[2], it[3]) }
        form.addView(Button(this).apply { text = "+ افزودن ردیف معامله"; setOnClickListener { addRow() } })
        formScroll.addView(form)
        content.addView(formScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        lateinit var dialog: AlertDialog
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 8, 0, 8) }
        val cancel = Button(this).apply { text = "انصراف"; setOnClickListener { dialog.dismiss() } }
        val save = Button(this).apply {
            text = "ثبت معاملات"
            setOnClickListener {
                val trades = mutableListOf<Triple<String, Long, Long>>()
                for (i in 0 until rows.childCount) {
                    val r = rows.getChildAt(i) as LinearLayout
                    val s = (r.getChildAt(0) as EditText).text.toString().trim().uppercase(Locale.US)
                    val q = (r.getChildAt(1) as EditText).text.toString().trim().toLongOrNull()
                    val p = (r.getChildAt(2) as EditText).text.toString().trim().toLongOrNull()
                    if (s.isBlank() || q == null || q <= 0L || p == null || p < 0L) {
                        subStatus.text = "اطلاعات این ردیف کامل نیست. نماد، تعداد و قیمت را وارد کنید."
                        return@setOnClickListener
                    }
                    trades += Triple(s, q, p)
                }
                val error = db.replaceTrades(shareholderName, selectedDate, tradeType, trades)
                if (error != null) {
                    subStatus.text = error
                    return@setOnClickListener
                }
                status.text = "${toPersianDigits(trades.size.toString())} معامله $tradeType برای ${toPersianDate(selectedDate)} ثبت شد."
                refreshTable()
                dialog.dismiss()
            }
        }
        buttons.addView(cancel, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        buttons.addView(save, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        content.addView(buttons)
        dialog = AlertDialog.Builder(this).setTitle("Subform $tradeType — ${toPersianDate(selectedDate)}").setView(content).create()
        dialog.show()
    }

    companion object {
        private const val REQUEST_PORTFOLIO = 1001
        private const val REQUEST_ORDERS = 1002
    }

    private fun pickExcel(requestCode: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        }
        startActivityForResult(intent, requestCode)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        try {
            val rows = XlsxReader.read(this, data.data!!)
            if (rows.size < 2) throw IllegalArgumentException("فایل Excel داده‌ای ندارد.")
            if (requestCode == REQUEST_PORTFOLIO) importPortfolio(rows, data.data!!) else importOrders(rows, data.data!!)
        } catch (e: Exception) {
            status.text = "خطا در خواندن Excel: ${e.message ?: "فایل نامعتبر است."}"
        }
    }

    private fun normalizeDigits(v: String): String = v.map {
        when (it) { '۰' -> '0'; '۱' -> '1'; '۲' -> '2'; '۳' -> '3'; '۴' -> '4'; '۵' -> '5'; '۶' -> '6'; '۷' -> '7'; '۸' -> '8'; '۹' -> '9'; else -> it }
    }.joinToString("")

    private fun normalizeDate(v: String): String {
        val s = normalizeDigits(v.trim()).replace('/', '-').replace('.', '-')
        if (Regex("\\d{8}").matches(s)) {
            val y = s.substring(0, 4).toInt()
            val m = s.substring(4, 6).toInt()
            val d = s.substring(6, 8).toInt()
            return if (y >= 1900) formatDate(gregorianToJalali(y, m, d)) else String.format("%04d-%02d-%02d", y, m, d)
        }
        if (Regex("\\d{4}-\\d{2}-\\d{2}").matches(s)) {
            val y = s.substring(0, 4).toInt()
            return if (y >= 1900) {
                val m = s.substring(5, 7).toInt(); val d = s.substring(8, 10).toInt()
                formatDate(gregorianToJalali(y, m, d))
            } else s
        }
        return s
    }

    private fun headerIndex(header: List<String>, name: String): Int = header.indexOfFirst { it.trim() == name.trim() }

    private fun importPortfolio(rows: List<List<String>>, uri: Uri) {
        val h = rows.first().map { it.trim() }
        val symbol = headerIndex(h, "نام نماد")
        val qty = headerIndex(h, "تعداد دارایی")
        val bonus = headerIndex(h, "تعداد سهام جایزه")
        val right = headerIndex(h, "تعداد حق تقدم")
        val last = headerIndex(h, "آخرین قیمت")
        val avg = headerIndex(h, "قیمت میانگین کل خرید با لحاظ کارمزد")
        val optionalDate = headerIndex(h, "تاریخ آخرین تراکنش و رویداد")
        if (listOf(symbol, qty, bonus, right, last, avg).any { it < 0 }) throw IllegalArgumentException("ستون‌های لازم فایل پرتفوی پیدا نشد. باید ۶ فیلد پرتفوی موجود باشد.")
        val parsed = rows.drop(1).filter { it.getOrNull(symbol)?.isNotBlank() == true }.map { r ->
            arrayOf(r[symbol].trim(), cleanNumber(r[qty]), cleanNumber(r[bonus]), cleanNumber(r[right]), cleanNumber(r[last]), cleanNumber(r[avg]))
        }
        if (parsed.isEmpty()) throw IllegalArgumentException("هیچ نمادی در فایل پرتفوی پیدا نشد.")
        val fileDates = if (optionalDate >= 0) rows.drop(1).mapNotNull { it.getOrNull(optionalDate)?.takeIf { v -> v.isNotBlank() }?.let { normalizeDate(it) } }.distinct() else emptyList()
        val fileDate = if (fileDates.size == 1) fileDates.first() else ""
        val dateEdit = edit(if (fileDate.isNotBlank()) toPersianDate(fileDate) else toPersianDate(today()))
        dateEdit.hint = "۱۴۰۵/۰۹/۰۱"
        AlertDialog.Builder(this)
            .setTitle("تاریخ ثبت پرتفوی")
            .setMessage("این فایل ۶ فیلد پرتفوی دارد. تاریخ Snapshot را مشخص کنید:")
            .setView(dateEdit)
            .setNegativeButton("انصراف", null)
            .setPositiveButton("ثبت پرتفوی") { _, _ ->
                val snapshotDate = normalizeDate(dateEdit.text.toString())
                if (!Regex("\\d{4}-\\d{2}-\\d{2}").matches(snapshotDate)) {
                    status.text = "تاریخ را به شکل ۱۴۰۵/۰۹/۰۱ وارد کنید."
                    return@setPositiveButton
                }
                db.savePortfolioSnapshot(shareholder.selectedItem.toString(), snapshotDate, parsed, "Portfolio")
                status.text = "پرتفوی ${toPersianDigits(parsed.size.toString())} نماد برای تاریخ ${toPersianDate(snapshotDate)} ثبت شد."
                refreshSummary()
                refreshPortfolioTable()
                refreshTable()
            }.show()
    }

    private fun importOrders(rows: List<List<String>>, uri: Uri) {
        val h = rows.first()
        val date = headerIndex(h, "تاریخ")
        val time = headerIndex(h, "ساعت")
        val side = headerIndex(h, "سمت سفارش")
        val symbol = headerIndex(h, "نماد")
        val price = headerIndex(h, "قیمت")
        val doneQty = headerIndex(h, "حجم انجام شده")
        val statusCol = headerIndex(h, "وضعیت")
        if (listOf(date,time,side,symbol,price,doneQty,statusCol).any { it < 0 }) throw IllegalArgumentException("ستون‌های لازم فایل سفارشات پیدا نشد.")
        val parsed = rows.drop(1).filter {
            it.getOrNull(statusCol)?.trim() == "انجام شده" && (cleanNumber(it.getOrNull(doneQty) ?: "").toLongOrNull() ?: 0L) > 0
        }.map { r ->
            arrayOf(normalizeDate(r[date]), r[time].trim(), r[side].trim(), r[symbol].trim(), cleanNumber(r[doneQty]), cleanNumber(r[price]))
        }
        if (parsed.isEmpty()) { status.text = "هیچ معامله انجام‌شده‌ای در فایل سفارشات پیدا نشد."; return }
        db.saveImportedTransactions(shareholder.selectedItem.toString(), parsed, "Orders")
        val dates = parsed.map { it[0] }.distinct().sorted()
        status.text = "${toPersianDigits(parsed.size.toString())} معامله انجام‌شده از ${toPersianDate(dates.first())} تا ${toPersianDate(dates.last())} وارد شد."
        refreshTable()
    }

    private fun cleanNumber(v: String): String = normalizeDigits(v.trim()).replace(",", "").replace("٬", "").replace("٫", ".")

    private fun renameShareholder() {
        val oldName = shareholder.selectedItem?.toString() ?: return
        val e = edit(oldName)
        AlertDialog.Builder(this).setTitle("ویرایش نام سهامدار").setView(e).setNegativeButton("انصراف", null).setPositiveButton("ذخیره") { _, _ ->
            val newName = e.text.toString().trim()
            if (newName.isBlank()) { status.text = "نام سهامدار نمی‌تواند خالی باشد."; return@setPositiveButton }
            if (!db.renameShareholder(oldName, newName)) { status.text = "این نام قبلاً وجود دارد یا تغییری انجام نشده است."; return@setPositiveButton }
            shareholder.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, db.shareholders())
            status.text = "نام سهامدار به «$newName» تغییر کرد و سوابق قبلی حفظ شد."
            refreshTable()
        }.show()
    }

    private fun addField(root: LinearLayout, label: String, view: View) { root.addView(TextView(this).apply { text = label; textSize = 13f }); root.addView(view, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)) }
    private fun edit(value: String) = EditText(this).apply { setText(value); inputType = InputType.TYPE_CLASS_TEXT }
    private fun money(v: Long): String = if (v == 0L) "—" else toPersianDigits(String.format(Locale.US, "%,d", v)) + " ریال"
    private fun currentMonth(): String { val j = gregorianToJalali(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH)+1, Calendar.getInstance().get(Calendar.DAY_OF_MONTH)); return String.format("%04d-%02d", j[0], j[1]) }
    private fun today(): String { val c = Calendar.getInstance(); return formatDate(gregorianToJalali(c.get(Calendar.YEAR), c.get(Calendar.MONTH)+1, c.get(Calendar.DAY_OF_MONTH))) }

    private fun toPersianDigits(v: String): String = v.map { ch -> when (ch) { '0' -> '۰'; '1' -> '۱'; '2' -> '۲'; '3' -> '۳'; '4' -> '۴'; '5' -> '۵'; '6' -> '۶'; '7' -> '۷'; '8' -> '۸'; '9' -> '۹'; else -> ch } }.joinToString("")
    private fun toPersianDate(v: String): String = toPersianDigits(v.replace('-', '/'))
    private fun formatDate(j: IntArray): String = String.format(Locale.US, "%04d-%02d-%02d", j[0], j[1], j[2])
    private fun jalaliMonthDays(year: Int, month: Int): Int = when { month in 1..6 -> 31; month in 7..11 -> 30; else -> if (isJalaliLeap(year)) 30 else 29 }
    private fun isJalaliLeap(year: Int): Boolean { val r = year % 33; return r in listOf(1,5,9,13,17,22,26,30) }

    private fun gregorianToJalali(gy: Int, gm: Int, gd: Int): IntArray {
        var y = gy - 1600; var m = gm - 1; var d = gd - 1
        val gdm = intArrayOf(31,28,31,30,31,30,31,31,30,31,30,31)
        var gDayNo = 365*y + (y+3)/4 - (y+99)/100 + (y+399)/400
        for (i in 0 until m) gDayNo += gdm[i]
        if (m > 1 && ((gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0)) gDayNo++
        gDayNo += d
        var jDayNo = gDayNo - 79
        val jNp = jDayNo / 12053; jDayNo %= 12053
        var jy = 979 + 33*jNp + 4*(jDayNo/1461); jDayNo %= 1461
        if (jDayNo >= 366) { jy += (jDayNo-1)/365; jDayNo = (jDayNo-1)%365 }
        val jm: Int; val jd: Int
        if (jDayNo < 186) { jm = 1 + jDayNo/31; jd = 1 + jDayNo%31 } else { jm = 7 + (jDayNo-186)/30; jd = 1 + (jDayNo-186)%30 }
        return intArrayOf(jy, jm, jd)
    }

    private fun exportCsv() {
        val who = shareholder.selectedItem.toString()
        val csv = buildString { append("سهامدار,نماد,نوع,تعداد,قیمت,تاریخ\n"); db.allFor(who).forEach { r -> append(r.joinToString(",") { v -> "\"" + v.replace("\"", "\"\"") + "\"" }).append("\n") } }
        val v = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, "Report-saham-$who-${today()}.csv"); put(MediaStore.Downloads.MIME_TYPE, "text/csv"); put(MediaStore.Downloads.RELATIVE_PATH, "Download") }
        contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)?.let { uri -> contentResolver.openOutputStream(uri)?.use { it.write(byteArrayOf(0xEF.toByte(),0xBB.toByte(),0xBF.toByte())); it.write(csv.toByteArray(Charsets.UTF_8)) }; status.text = "گزارش CSV سهامدار $who ذخیره شد." }
    }

    private fun exportPdf() {
        val who = shareholder.selectedItem.toString(); val doc = PdfDocument(); val page = doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create()); val c = page.canvas
        val p = android.graphics.Paint().apply { textSize = 11f; color = Color.BLACK }; var y = 40f
        c.drawText("Report Saham - $who", 30f, y, p); y += 25f
        db.allFor(who).take(35).forEach { c.drawText(it.joinToString(" | ").take(100), 30f, y, p); y += 18f }
        doc.finishPage(page)
        val v = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, "Report-saham-$who-${today()}.pdf"); put(MediaStore.Downloads.MIME_TYPE, "application/pdf"); put(MediaStore.Downloads.RELATIVE_PATH, "Download") }
        contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)?.let { uri -> contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) }; status.text = "گزارش PDF سهامدار $who ذخیره شد." }; doc.close()
    }
}
