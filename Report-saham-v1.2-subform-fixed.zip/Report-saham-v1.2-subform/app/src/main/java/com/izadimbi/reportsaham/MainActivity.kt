package com.izadimbi.reportsaham

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var db: PortfolioDb
    private lateinit var shareholder: Spinner
    private lateinit var date: EditText
    private lateinit var status: TextView
    private lateinit var dailySummary: TextView
    private lateinit var list: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = PortfolioDb(this)
        buildUi()
        refresh()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24,24,24,24); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        root.addView(TextView(this).apply { text="گزارش سهام — فرم مستقل هر سهامدار"; textSize=21f; setTypeface(null,Typeface.BOLD); setPadding(0,0,0,18) })
        shareholder = Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, db.shareholders()) }
        addField(root,"سهامدار",shareholder)
        date = edit(today()); addField(root,"تاریخ گزارش (YYYY-MM-DD)",date)

        val buy = Button(this).apply { text="ثبت گزارش خرید — Subform"; setOnClickListener { openTradeSubform("خرید") } }
        val sell = Button(this).apply { text="ثبت گزارش فروش — Subform"; setOnClickListener { openTradeSubform("فروش") } }
        root.addView(buy); root.addView(sell)

        dailySummary = TextView(this).apply { textSize=14f; setPadding(0,14,0,8) }; root.addView(dailySummary)
        status = TextView(this).apply { textSize=14f; setPadding(0,8,0,8) }; root.addView(status)

        val reportRow=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val csv=Button(this).apply{text="Excel/CSV"}; val pdf=Button(this).apply{text="PDF"}
        reportRow.addView(csv,LinearLayout.LayoutParams(0,WRAP,1f)); reportRow.addView(pdf,LinearLayout.LayoutParams(0,WRAP,1f)); root.addView(reportRow)
        csv.setOnClickListener{exportCsv()}; pdf.setOnClickListener{exportPdf()}

        list=TextView(this).apply{textSize=13f}; val scroll=ScrollView(this); scroll.addView(list); root.addView(scroll,LinearLayout.LayoutParams(MATCH,0,1f))
        shareholder.onItemSelectedListener=object: AdapterView.OnItemSelectedListener { override fun onNothingSelected(p:AdapterView<*>?){}; override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){refresh()} }
        setContentView(root)
    }

    private fun openTradeSubform(tradeType:String) {
        val container=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setPadding(12,4,12,4)}
        val rows=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        container.addView(TextView(this).apply{text="${tradeType} — جزئیات معاملات این روز"; textSize=17f; setTypeface(null,Typeface.BOLD); setPadding(0,0,0,12)})
        container.addView(rows)
        fun addRow() {
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL; setPadding(0,4,0,4)}
            val symbol=EditText(this).apply{hint="نماد"; setText("فولاد"); inputType=InputType.TYPE_CLASS_TEXT}
            val qty=EditText(this).apply{hint="تعداد"; inputType=InputType.TYPE_CLASS_NUMBER}
            val price=EditText(this).apply{hint="قیمت"; inputType=InputType.TYPE_CLASS_NUMBER}
            val remove=Button(this).apply{text="حذف"}
            row.addView(symbol,LinearLayout.LayoutParams(0,WRAP,1.1f)); row.addView(qty,LinearLayout.LayoutParams(0,WRAP,1f)); row.addView(price,LinearLayout.LayoutParams(0,WRAP,1f)); row.addView(remove,LinearLayout.LayoutParams(0,WRAP,.65f))
            remove.setOnClickListener{rows.removeView(row)}
            rows.addView(row)
        }
        addRow()
        val add=Button(this).apply{text="+ افزودن ردیف معامله"; setOnClickListener{addRow()}}; container.addView(add)
        val scroll=ScrollView(this).apply{addView(container)}
        val dialog=AlertDialog.Builder(this).setTitle("Subform ثبت $tradeType").setView(scroll).setNegativeButton("انصراف",null).create()
        dialog.setButton(AlertDialog.BUTTON_POSITIVE,"ثبت گزارش") { _,_ ->
            var count=0; var error:String?=null
            for(i in 0 until rows.childCount) {
                val r=rows.getChildAt(i) as LinearLayout
                val s=(r.getChildAt(0) as EditText).text.toString().trim().uppercase(Locale.US)
                val q=(r.getChildAt(1) as EditText).text.toString().toLongOrNull()
                val p=(r.getChildAt(2) as EditText).text.toString().toLongOrNull()
                if(s.isBlank() || q==null || q<=0 || p==null || p<0){error="یکی از ردیف‌ها اطلاعات کامل ندارد.";break}
                if(tradeType=="فروش") { val available=db.currentHolding(shareholder.selectedItem.toString(),s); if(q>available){error="فروش $s ثبت نشد؛ موجودی فعلی: $available سهم";break} }
                db.insert(shareholder.selectedItem.toString(),s,tradeType,q,p,date.text.toString().trim()); count++
            }
            status.text=error ?: "$count معامله $tradeType برای ${shareholder.selectedItem} ثبت شد."; refresh()
        }
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled=true
    }

    private fun refresh(){ if(!::list.isInitialized)return; val who=shareholder.selectedItem?.toString()?:return; val d=date.text.toString().trim(); val totals=db.dailyTotals(who,d); dailySummary.text="گزارش روز: $d\nجمع خرید: ${totals.first}    |    جمع فروش: ${totals.second}"; list.text=db.recentFor(who,100).joinToString("\n") }
    private fun addField(root:LinearLayout,label:String,view:View){root.addView(TextView(this).apply{text=label;textSize=13f});root.addView(view,LinearLayout.LayoutParams(MATCH,WRAP))}
    private fun edit(value:String)=EditText(this).apply{setText(value);inputType=InputType.TYPE_CLASS_TEXT}
    private fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())

    private fun exportCsv(){ val who=shareholder.selectedItem.toString(); val csv=buildString{append("سهامدار,نماد,نوع,تعداد,قیمت,تاریخ\n");db.allFor(who).forEach{r->append(r.joinToString(","){v->"\""+v.replace("\"","\"\"")+"\""}).append("\n")}}; val v=ContentValues().apply{put(MediaStore.Downloads.DISPLAY_NAME,"Report-saham-$who-${today()}.csv");put(MediaStore.Downloads.MIME_TYPE,"text/csv");put(MediaStore.Downloads.RELATIVE_PATH,"Download")};contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v)?.let{uri->contentResolver.openOutputStream(uri)?.use{it.write(byteArrayOf(0xEF.toByte(),0xBB.toByte(),0xBF.toByte()));it.write(csv.toByteArray(Charsets.UTF_8))};status.text="گزارش CSV سهامدار $who ذخیره شد."}}
    private fun exportPdf(){val who=shareholder.selectedItem.toString();val doc=PdfDocument();val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create());val c=page.canvas;val p=android.graphics.Paint().apply{textSize=11f;color=Color.BLACK};var y=40f;c.drawText("Report Saham - $who",30f,y,p);y+=25f;db.allFor(who).take(35).forEach{c.drawText(it.joinToString(" | ").take(100),30f,y,p);y+=18f};doc.finishPage(page);val v=ContentValues().apply{put(MediaStore.Downloads.DISPLAY_NAME,"Report-saham-$who-${today()}.pdf");put(MediaStore.Downloads.MIME_TYPE,"application/pdf");put(MediaStore.Downloads.RELATIVE_PATH,"Download")};contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v)?.let{uri->contentResolver.openOutputStream(uri)?.use{doc.writeTo(it)};status.text="گزارش PDF سهامدار $who ذخیره شد."};doc.close()}
    companion object{const val MATCH=LinearLayout.LayoutParams.MATCH_PARENT;const val WRAP=LinearLayout.LayoutParams.WRAP_CONTENT}
}
