plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.izadimbi.reportsaham"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.izadimbi.reportsaham"
        minSdk = 24
        targetSdk = 35
        versionCode = 3
        versionName = "1.2-subform"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
